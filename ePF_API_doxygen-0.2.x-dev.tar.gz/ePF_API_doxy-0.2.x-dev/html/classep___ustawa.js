var classep___ustawa =
[
    [ "__toString", "classep___ustawa.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___ustawa.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "parse_data", "classep___ustawa.html#ac313783ab7146c71e639bf7ddf54b0db", null ],
    [ "prawo", "classep___ustawa.html#aa2dddcb8b56680f840b6b3a40b49079f", null ],
    [ "projekty_zmian", "classep___ustawa.html#a07530796b374ac86eb68d756aeb2ba04", null ],
    [ "set_ep_Prawo", "classep___ustawa.html#a5dcc76545ca583093765bc7e1dd3f175", null ],
    [ "$_aliases", "classep___ustawa.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];