var classep___sejm___posiedzenie___punkt =
[
    [ "__toString", "classep___sejm___posiedzenie___punkt.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "debaty", "classep___sejm___posiedzenie___punkt.html#a61f284b69abf1b9994fb0531fd5072ec", null ],
    [ "druki", "classep___sejm___posiedzenie___punkt.html#af22894fe8830155fc20716e34f1f1c33", null ],
    [ "getDataStruct", "classep___sejm___posiedzenie___punkt.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "glosowania", "classep___sejm___posiedzenie___punkt.html#a053e53f5c6126e89ed49774ba8f12ec9", null ],
    [ "posiedzenie", "classep___sejm___posiedzenie___punkt.html#abfdc29f0533665ad6c77341c5fa3f7c7", null ],
    [ "wystapienia", "classep___sejm___posiedzenie___punkt.html#a18b1bf1c04262c23e5edc5c81a4f897c", null ],
    [ "$_aliases", "classep___sejm___posiedzenie___punkt.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];