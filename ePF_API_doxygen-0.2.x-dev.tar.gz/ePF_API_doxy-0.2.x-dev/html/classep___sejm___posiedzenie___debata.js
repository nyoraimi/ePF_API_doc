var classep___sejm___posiedzenie___debata =
[
    [ "__toString", "classep___sejm___posiedzenie___debata.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "dzien", "classep___sejm___posiedzenie___debata.html#a211a968a9f3aa1e4a58516f8c344ec00", null ],
    [ "getDataStruct", "classep___sejm___posiedzenie___debata.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "glosowania", "classep___sejm___posiedzenie___debata.html#a053e53f5c6126e89ed49774ba8f12ec9", null ],
    [ "posiedzenie", "classep___sejm___posiedzenie___debata.html#abfdc29f0533665ad6c77341c5fa3f7c7", null ],
    [ "punkt", "classep___sejm___posiedzenie___debata.html#a33d6419a012729a56ab84c223a587ee2", null ],
    [ "wystapienia", "classep___sejm___posiedzenie___debata.html#a18b1bf1c04262c23e5edc5c81a4f897c", null ],
    [ "$_aliases", "classep___sejm___posiedzenie___debata.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];