var classep___senat___wystapienie =
[
    [ "__construct", "classep___senat___wystapienie.html#a8c384d5e0f13f64cbf8c51096faa7738", null ],
    [ "__toString", "classep___senat___wystapienie.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___senat___wystapienie.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "mowca", "classep___senat___wystapienie.html#a0a281f2a729be7088e24f59b2a897bb6", null ],
    [ "set_ep_mowcy", "classep___senat___wystapienie.html#a394835ac1f34d44b5181f5e2e704deb4", null ],
    [ "set_ep_stanowiska", "classep___senat___wystapienie.html#a57f2e23f1d143edd2d513c213b5a0f52", null ],
    [ "stanowisko", "classep___senat___wystapienie.html#a3d84fd752ff96edc69fbe27a52d8d3d7", null ],
    [ "$_aliases", "classep___senat___wystapienie.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];