var classep___glosowanie___sejmowe___glos =
[
    [ "__toString", "classep___glosowanie___sejmowe___glos.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___glosowanie___sejmowe___glos.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "posel", "classep___glosowanie___sejmowe___glos.html#ad3b9fc55831f7bcabb4870306bc08f4b", null ],
    [ "set_ep_poslowie", "classep___glosowanie___sejmowe___glos.html#a6a354494d54778bcc9254b5826b5f28c", null ],
    [ "$_aliases", "classep___glosowanie___sejmowe___glos.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];