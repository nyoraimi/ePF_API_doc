var classep___posel =
[
    [ "__toString", "classep___posel.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "aktywnosci", "classep___posel.html#af32786fc0cc85c7b2d9d66c3923b3197", null ],
    [ "getDataStruct", "classep___posel.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "glosy", "classep___posel.html#aab9cc82c80e91ad71187a3c4a9999561", null ],
    [ "klub", "classep___posel.html#aedba85bfa40b8bf60cfad39464010834", null ],
    [ "komisje_stanowiska", "classep___posel.html#a79f06cfb4c9c98b98876067012f2c413", null ],
    [ "mowca", "classep___posel.html#a0a281f2a729be7088e24f59b2a897bb6", null ],
    [ "oswiadczenia_majatkowe", "classep___posel.html#ab7a97df64d38268bc2d006b6666d0275", null ],
    [ "projekty_uchwal", "classep___posel.html#a14881c701cfb2df51d012218c1494a51", null ],
    [ "projekty_ustaw", "classep___posel.html#a77464a8191912ee711ebcaa03fb0bf94", null ],
    [ "rejestr_korzysci", "classep___posel.html#a6c022f0121768edc931338ecb59e0dca", null ],
    [ "set_ep_ludzie", "classep___posel.html#a26923a78d5c508d37507edd1b617893c", null ],
    [ "set_ep_sejm_kluby", "classep___posel.html#ab890bc062f51edbd126a1b10bd326e71", null ],
    [ "twitty", "classep___posel.html#a8ef2e15fbe3d18191cb256c026a211be", null ],
    [ "wspolpracownicy", "classep___posel.html#a7139261a26ea9ad6c952fddb860c80d9", null ],
    [ "wystapienia", "classep___posel.html#a18b1bf1c04262c23e5edc5c81a4f897c", null ],
    [ "$_aliases", "classep___posel.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___posel.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];