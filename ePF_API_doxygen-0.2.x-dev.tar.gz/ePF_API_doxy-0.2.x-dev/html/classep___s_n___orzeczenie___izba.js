var classep___s_n___orzeczenie___izba =
[
    [ "getDataStruct", "classep___s_n___orzeczenie___izba.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "orzeczenie_sn", "classep___s_n___orzeczenie___izba.html#ad3ca9a024234af7b90b52e8edb3406ff", null ],
    [ "orzeczenie_sn_izba", "classep___s_n___orzeczenie___izba.html#ad33bb7ef5f99e5950c5994a501361b1c", null ],
    [ "$_aliases", "classep___s_n___orzeczenie___izba.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_orzeczenie_sn", "classep___s_n___orzeczenie___izba.html#a03da9aa4f10fbe1d2b4ef32521cbedb0", null ],
    [ "$_orzeczenie_sn_izba", "classep___s_n___orzeczenie___izba.html#a03bb0e40e6b5ea8dc5d273a501e27211", null ]
];