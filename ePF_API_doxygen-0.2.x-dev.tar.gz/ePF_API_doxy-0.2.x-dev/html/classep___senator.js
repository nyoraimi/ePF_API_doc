var classep___senator =
[
    [ "__toString", "classep___senator.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___senator.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "komisje", "classep___senator.html#a66895e14014726b555618e5b409771bd", null ],
    [ "oswiadczenia_majatkowe", "classep___senator.html#ab7a97df64d38268bc2d006b6666d0275", null ],
    [ "rejestr_korzysci", "classep___senator.html#a6c022f0121768edc931338ecb59e0dca", null ],
    [ "wystapienia", "classep___senator.html#a18b1bf1c04262c23e5edc5c81a4f897c", null ],
    [ "zespoly_parlamentarne", "classep___senator.html#acf90e2692da0f334ab0dfce03e3a9e7a", null ],
    [ "zespoly_senackie", "classep___senator.html#ae0fd986698b921926b3d3f6f3c6fd674", null ],
    [ "$_aliases", "classep___senator.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___senator.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];