var searchData=
[
  ['sp_5forzeczenie_5fsn_5fsprawozdawca',['sp_Orzeczenie_SN_Sprawozdawca',['../classsp___orzeczenie___s_n___sprawozdawca.html',1,'']]]
];
