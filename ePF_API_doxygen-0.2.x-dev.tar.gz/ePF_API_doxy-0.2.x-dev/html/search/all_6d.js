var searchData=
[
  ['mowca',['mowca',['../classep___posel.html#a0a281f2a729be7088e24f59b2a897bb6',1,'ep_Posel\mowca()'],['../classep___sejm___wystapienie.html#a0a281f2a729be7088e24f59b2a897bb6',1,'ep_Sejm_Wystapienie\mowca()'],['../classep___senat___wystapienie.html#a0a281f2a729be7088e24f59b2a897bb6',1,'ep_Senat_Wystapienie\mowca()']]]
];
