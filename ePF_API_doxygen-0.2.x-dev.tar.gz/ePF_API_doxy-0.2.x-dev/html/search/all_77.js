var searchData=
[
  ['where',['where',['../classep___dataset.html#aa850d279b606c6c1e77d3bb71e6bd65b',1,'ep_Dataset']]],
  ['wojewodztwa',['wojewodztwa',['../classep___b_d_l___wskaznik___wariacja.html#acb04fcd1fcf58babff11d13c0b03d053',1,'ep_BDL_Wskaznik_Wariacja']]],
  ['wojewodztwo',['wojewodztwo',['../classep___gmina.html#a2c735142a4af50d47b17d8103a9ab9ab',1,'ep_Gmina\wojewodztwo()'],['../classep___kod___pocztowy.html#a2c735142a4af50d47b17d8103a9ab9ab',1,'ep_Kod_Pocztowy\wojewodztwo()'],['../classep___miejscowosc.html#a2c735142a4af50d47b17d8103a9ab9ab',1,'ep_Miejscowosc\wojewodztwo()'],['../classep___p_n_a.html#a2c735142a4af50d47b17d8103a9ab9ab',1,'ep_PNA\wojewodztwo()'],['../classep___powiat.html#a2c735142a4af50d47b17d8103a9ab9ab',1,'ep_Powiat\wojewodztwo()']]],
  ['wspolpracownicy',['wspolpracownicy',['../classep___posel.html#a7139261a26ea9ad6c952fddb860c80d9',1,'ep_Posel']]],
  ['wspolsprawozdawcy',['wspolsprawozdawcy',['../classep___s_n___orzeczenie.html#a6c6f87dc07e219e95c13638d943a60eb',1,'ep_SN_Orzeczenie']]],
  ['wynik',['wynik',['../classep___s_a___orzeczenie.html#a4fc8dd9c4cd638f3254e1cd146211b7d',1,'ep_SA_Orzeczenie']]],
  ['wystapienia',['wystapienia',['../classep___posel.html#a18b1bf1c04262c23e5edc5c81a4f897c',1,'ep_Posel\wystapienia()'],['../classep___sejm___posiedzenie.html#a18b1bf1c04262c23e5edc5c81a4f897c',1,'ep_Sejm_Posiedzenie\wystapienia()'],['../classep___sejm___posiedzenie___debata.html#a18b1bf1c04262c23e5edc5c81a4f897c',1,'ep_Sejm_Posiedzenie_Debata\wystapienia()'],['../classep___sejm___posiedzenie___punkt.html#a18b1bf1c04262c23e5edc5c81a4f897c',1,'ep_Sejm_Posiedzenie_Punkt\wystapienia()'],['../classep___sejm___pytanie___biezace.html#a18b1bf1c04262c23e5edc5c81a4f897c',1,'ep_Sejm_Pytanie_Biezace\wystapienia()'],['../classep___senator.html#a18b1bf1c04262c23e5edc5c81a4f897c',1,'ep_Senator\wystapienia()']]],
  ['wystapienie',['wystapienie',['../classep___sejm___glosowanie.html#aa051a476b68537f178e14ee797250288',1,'ep_Sejm_Glosowanie']]]
];
