var searchData=
[
  ['zespol_5fparlamentarny',['zespol_parlamentarny',['../classep___senat__senator__zespol__parlamentarny.html#ab35c0c9aed2d5fc6af85be9289f9f2a1',1,'ep_Senat_senator_zespol_parlamentarny']]],
  ['zespol_5fsenacki',['zespol_senacki',['../classep___senat__senator__zespol__senacki.html#af6439a809c6c1a83d25215a86e3f2090',1,'ep_Senat_senator_zespol_senacki']]],
  ['zespoly_5fparlamentarne',['zespoly_parlamentarne',['../classep___senator.html#acf90e2692da0f334ab0dfce03e3a9e7a',1,'ep_Senator']]],
  ['zespoly_5fsenackie',['zespoly_senackie',['../classep___senator.html#ae0fd986698b921926b3d3f6f3c6fd674',1,'ep_Senator']]],
  ['zmieniane_5fustawy',['zmieniane_ustawy',['../classep___legislacja___projekt.html#a8f7f16f34f1627d96a79ae2a18423970',1,'ep_Legislacja_Projekt']]]
];
