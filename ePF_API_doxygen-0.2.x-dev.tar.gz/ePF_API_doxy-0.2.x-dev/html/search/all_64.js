var searchData=
[
  ['debata',['debata',['../classep___sejm___glosowanie.html#a7fe12606c5b0d87a6f1d26d2470a10c2',1,'ep_Sejm_Glosowanie\debata()'],['../classep___sejm___wystapienie.html#a7fe12606c5b0d87a6f1d26d2470a10c2',1,'ep_Sejm_Wystapienie\debata()']]],
  ['debaty',['debaty',['../classep___sejm___dzien.html#a61f284b69abf1b9994fb0531fd5072ec',1,'ep_Sejm_Dzien\debaty()'],['../classep___sejm___posiedzenie___punkt.html#a61f284b69abf1b9994fb0531fd5072ec',1,'ep_Sejm_Posiedzenie_Punkt\debaty()']]],
  ['dni',['dni',['../classep___sejm___posiedzenie.html#ad8bc0547af9d7792114185786ca4d8e9',1,'ep_Sejm_Posiedzenie']]],
  ['druki',['druki',['../classep___sejm___druk___typ.html#af22894fe8830155fc20716e34f1f1c33',1,'ep_Sejm_Druk_Typ\druki()'],['../classep___sejm___posiedzenie___punkt.html#af22894fe8830155fc20716e34f1f1c33',1,'ep_Sejm_Posiedzenie_Punkt\druki()']]],
  ['dzien',['dzien',['../classep___sejm___glosowanie.html#a211a968a9f3aa1e4a58516f8c344ec00',1,'ep_Sejm_Glosowanie\dzien()'],['../classep___sejm___posiedzenie___debata.html#a211a968a9f3aa1e4a58516f8c344ec00',1,'ep_Sejm_Posiedzenie_Debata\dzien()'],['../classep___sejm___pytanie___biezace.html#a211a968a9f3aa1e4a58516f8c344ec00',1,'ep_Sejm_Pytanie_Biezace\dzien()']]]
];
