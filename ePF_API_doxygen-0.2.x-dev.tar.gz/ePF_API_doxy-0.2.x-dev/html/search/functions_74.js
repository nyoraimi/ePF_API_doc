var searchData=
[
  ['tablica',['tablica',['../classep___r_c_l___projekt.html#a562ec137b68d83aa36dd84a6f26c3394',1,'ep_RCL_Projekt\tablica()'],['../classep___sejm___interpelacja.html#a562ec137b68d83aa36dd84a6f26c3394',1,'ep_Sejm_Interpelacja\tablica()']]],
  ['twitty',['twitty',['../classep___posel.html#a8ef2e15fbe3d18191cb256c026a211be',1,'ep_Posel']]]
];
