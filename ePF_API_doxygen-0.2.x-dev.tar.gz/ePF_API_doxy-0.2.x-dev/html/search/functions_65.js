var searchData=
[
  ['etapy',['etapy',['../classep___legislacja___projekt.html#a3dcbe271e680ead3863303e13573c195',1,'ep_Legislacja_Projekt']]]
];
