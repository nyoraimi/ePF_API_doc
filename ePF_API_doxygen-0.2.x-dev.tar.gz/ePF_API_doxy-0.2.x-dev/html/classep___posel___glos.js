var classep___posel___glos =
[
    [ "__toString", "classep___posel___glos.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___posel___glos.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "glosowanie", "classep___posel___glos.html#aa9c48ea23fb8c76dd004f67b72fd4d90", null ],
    [ "set_ep_sejm_glosowania", "classep___posel___glos.html#a7dcb564db1d48eef20ad98cfaaddb4b7", null ],
    [ "$_aliases", "classep___posel___glos.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];