var classep___s_p___haslo =
[
    [ "getDataStruct", "classep___s_p___haslo.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "orzeczenie_sp", "classep___s_p___haslo.html#a498c7b61096c1bcb941e93a8d1385318", null ],
    [ "orzeczenie_sp_haslo_tematyczne", "classep___s_p___haslo.html#a62333df073de2eff05c3084aea3c0a05", null ],
    [ "$_aliases", "classep___s_p___haslo.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_orzeczenie_sp", "classep___s_p___haslo.html#aa2e1ecb50e6fae26a854ac995f7226b8", null ],
    [ "$_orzeczenie_sp_haslo_tematyczne", "classep___s_p___haslo.html#ad00ee90f32b429d419d6e1024bcda64b", null ]
];