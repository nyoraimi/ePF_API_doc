var classep___s_p___orzeczenie___czesc =
[
    [ "__toString", "classep___s_p___orzeczenie___czesc.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "get_wartosc", "classep___s_p___orzeczenie___czesc.html#a0fe99e5c9ee82a3647c1f719f51ed3c6", null ],
    [ "getDataStruct", "classep___s_p___orzeczenie___czesc.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "orzeczenie_sp", "classep___s_p___orzeczenie___czesc.html#a498c7b61096c1bcb941e93a8d1385318", null ],
    [ "$_aliases", "classep___s_p___orzeczenie___czesc.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_orzeczenie_sp", "classep___s_p___orzeczenie___czesc.html#aa2e1ecb50e6fae26a854ac995f7226b8", null ]
];