var classep___gmina =
[
    [ "__toString", "classep___gmina.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___gmina.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "obszar", "classep___gmina.html#aa05db5ea090acb5d431aff0bbb8b97a6", null ],
    [ "parse_data", "classep___gmina.html#ac313783ab7146c71e639bf7ddf54b0db", null ],
    [ "pna", "classep___gmina.html#a49db364aca99bded10aecb3c03b88151", null ],
    [ "poslowie", "classep___gmina.html#a0f86bc9d504d1c4a3a60c1585cb85f97", null ],
    [ "powiat", "classep___gmina.html#afeb09b2f0c7a3cd1d9bfe029ffdd57ea", null ],
    [ "set_ep_Powiat", "classep___gmina.html#abb5d24d51da3de254009201026fb912b", null ],
    [ "set_ep_powiaty", "classep___gmina.html#aad05e7a4455e489123c3cfc364b8583a", null ],
    [ "set_ep_wojewodztwa", "classep___gmina.html#a12fb54f8ef9461d5c7cad089ab5e35de", null ],
    [ "wojewodztwo", "classep___gmina.html#a2c735142a4af50d47b17d8103a9ab9ab", null ],
    [ "$_aliases", "classep___gmina.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___gmina.html#a4a4d54ae35428077a7c61ec8a5139af3", null ],
    [ "$_obszar", "classep___gmina.html#a78dbe56396c80cf6fc9d3f319bb5ec8c", null ],
    [ "$_poslowie_dataset", "classep___gmina.html#a7035a68c4348c4759daf71ac5c02b72e", null ],
    [ "$_powiat", "classep___gmina.html#a928275f8378baade592a64f89da229ef", null ],
    [ "$_wojewodztwo", "classep___gmina.html#a2a0a830e555a9e31b5118be82dbc33c7", null ]
];