var classep___legislacja___projekt =
[
    [ "__toString", "classep___legislacja___projekt.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "etapy", "classep___legislacja___projekt.html#a3dcbe271e680ead3863303e13573c195", null ],
    [ "getDataStruct", "classep___legislacja___projekt.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "podpisy_poslowie", "classep___legislacja___projekt.html#aa812d46d8996685e9583b7258aed9edd", null ],
    [ "zmieniane_ustawy", "classep___legislacja___projekt.html#a8f7f16f34f1627d96a79ae2a18423970", null ],
    [ "$_aliases", "classep___legislacja___projekt.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___legislacja___projekt.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];