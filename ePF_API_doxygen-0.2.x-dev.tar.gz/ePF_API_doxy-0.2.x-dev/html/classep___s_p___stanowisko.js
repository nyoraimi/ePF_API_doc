var classep___s_p___stanowisko =
[
    [ "__toString", "classep___s_p___stanowisko.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___s_p___stanowisko.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "orzeczenia_sp_osoby_stanowiska", "classep___s_p___stanowisko.html#a7f13cc1eeb3f1510b76d5fccde5bfdad", null ],
    [ "$_aliases", "classep___s_p___stanowisko.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___s_p___stanowisko.html#a4a4d54ae35428077a7c61ec8a5139af3", null ],
    [ "$_orzeczenia_sp_osoby_stanowiska", "classep___s_p___stanowisko.html#a96932ccc35af06bdee80dc8ce108397e", null ]
];