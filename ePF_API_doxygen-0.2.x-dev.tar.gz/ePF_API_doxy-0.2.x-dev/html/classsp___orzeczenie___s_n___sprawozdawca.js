var classsp___orzeczenie___s_n___sprawozdawca =
[
    [ "getDataStruct", "classsp___orzeczenie___s_n___sprawozdawca.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "orzeczenie_sn", "classsp___orzeczenie___s_n___sprawozdawca.html#ad3ca9a024234af7b90b52e8edb3406ff", null ],
    [ "orzeczenie_sn_osoba", "classsp___orzeczenie___s_n___sprawozdawca.html#abedbfb98ce259de97cc4ddfd5496797c", null ],
    [ "$_aliases", "classsp___orzeczenie___s_n___sprawozdawca.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_orzeczenie_sn", "classsp___orzeczenie___s_n___sprawozdawca.html#a03da9aa4f10fbe1d2b4ef32521cbedb0", null ],
    [ "$_orzeczenie_sn_osoba", "classsp___orzeczenie___s_n___sprawozdawca.html#a9ede817d229955b98ebe3e10f5a45e94", null ]
];