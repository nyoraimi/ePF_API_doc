var classep___b_d_l___wskaznik___wariacja =
[
    [ "__toString", "classep___b_d_l___wskaznik___wariacja.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___b_d_l___wskaznik___wariacja.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "gminy", "classep___b_d_l___wskaznik___wariacja.html#a885f04b428d85dab7d92552ae9dba979", null ],
    [ "podgrupa", "classep___b_d_l___wskaznik___wariacja.html#a6c73717d6fab642c6d5f3c5961724180", null ],
    [ "powiaty", "classep___b_d_l___wskaznik___wariacja.html#a1fb07b52f2e231d447866762258ab070", null ],
    [ "wojewodztwa", "classep___b_d_l___wskaznik___wariacja.html#acb04fcd1fcf58babff11d13c0b03d053", null ],
    [ "$_aliases", "classep___b_d_l___wskaznik___wariacja.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_podgrupa", "classep___b_d_l___wskaznik___wariacja.html#a0934a4cb9461f93073fd56a63cca6747", null ],
    [ "$_powiaty", "classep___b_d_l___wskaznik___wariacja.html#a97dc3eb2e2695666ed8ade0546691171", null ],
    [ "$_wojewodztwa", "classep___b_d_l___wskaznik___wariacja.html#a6e1a526b14484684c050725e04fc6185", null ]
];