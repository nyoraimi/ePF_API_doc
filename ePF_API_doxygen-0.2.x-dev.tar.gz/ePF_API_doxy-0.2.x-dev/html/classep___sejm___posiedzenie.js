var classep___sejm___posiedzenie =
[
    [ "__construct", "classep___sejm___posiedzenie.html#a8c384d5e0f13f64cbf8c51096faa7738", null ],
    [ "__toString", "classep___sejm___posiedzenie.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "dni", "classep___sejm___posiedzenie.html#ad8bc0547af9d7792114185786ca4d8e9", null ],
    [ "getDataStruct", "classep___sejm___posiedzenie.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "glosowania", "classep___sejm___posiedzenie.html#a053e53f5c6126e89ed49774ba8f12ec9", null ],
    [ "poslowie", "classep___sejm___posiedzenie.html#a0f86bc9d504d1c4a3a60c1585cb85f97", null ],
    [ "punkty", "classep___sejm___posiedzenie.html#a3ac343e2a424bd292fff8ff5301666c4", null ],
    [ "wystapienia", "classep___sejm___posiedzenie.html#a18b1bf1c04262c23e5edc5c81a4f897c", null ],
    [ "$_aliases", "classep___sejm___posiedzenie.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___sejm___posiedzenie.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];