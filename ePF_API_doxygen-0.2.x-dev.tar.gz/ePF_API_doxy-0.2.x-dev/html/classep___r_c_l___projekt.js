var classep___r_c_l___projekt =
[
    [ "__toString", "classep___r_c_l___projekt.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "autor", "classep___r_c_l___projekt.html#abbc80445668f2cd4fc3f91e27afdaebe", null ],
    [ "getDataStruct", "classep___r_c_l___projekt.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "set_ep_instytucje", "classep___r_c_l___projekt.html#a1d4b47aa7cd504faefc542efb5a975a1", null ],
    [ "tablica", "classep___r_c_l___projekt.html#a562ec137b68d83aa36dd84a6f26c3394", null ],
    [ "$_aliases", "classep___r_c_l___projekt.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];