var classep___sejm___komisja =
[
    [ "__toString", "classep___sejm___komisja.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___sejm___komisja.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "stanowiska", "classep___sejm___komisja.html#a9dd4480bf7002df382ab888d880131c2", null ],
    [ "$_aliases", "classep___sejm___komisja.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___sejm___komisja.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];