var classep___s_a___orzeczenie =
[
    [ "__construct", "classep___s_a___orzeczenie.html#a8c384d5e0f13f64cbf8c51096faa7738", null ],
    [ "__toString", "classep___s_a___orzeczenie.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___s_a___orzeczenie.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "sad", "classep___s_a___orzeczenie.html#a975f85bebff72c666d5edbcda34b71f2", null ],
    [ "sedziowie", "classep___s_a___orzeczenie.html#a8a15d60da65e02bae2cbdbf37b916e9f", null ],
    [ "set_ep_sa_orzeczenia_wyniki", "classep___s_a___orzeczenie.html#af21ad6bed19b284eec64bbf92d0cd688", null ],
    [ "set_ep_sa_sady", "classep___s_a___orzeczenie.html#ad89dcca53362d835ea728d79a7ef4161", null ],
    [ "set_ep_sa_skarzone_organy", "classep___s_a___orzeczenie.html#a09fc5ad08f45ee935307eaf11ae3223d", null ],
    [ "skarzony_organ", "classep___s_a___orzeczenie.html#a04a204d329b613d36ca895102f98e42e", null ],
    [ "wynik", "classep___s_a___orzeczenie.html#a4fc8dd9c4cd638f3254e1cd146211b7d", null ],
    [ "$_aliases", "classep___s_a___orzeczenie.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___s_a___orzeczenie.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];