var classep___orzeczenie__sp__osoba__stanowisko =
[
    [ "getDataStruct", "classep___orzeczenie__sp__osoba__stanowisko.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "orzeczenie_sp", "classep___orzeczenie__sp__osoba__stanowisko.html#a498c7b61096c1bcb941e93a8d1385318", null ],
    [ "orzeczenie_sp_osoba", "classep___orzeczenie__sp__osoba__stanowisko.html#a104627da416bbb3f34f3de3cc273cc3e", null ],
    [ "orzeczenie_sp_stanowisko", "classep___orzeczenie__sp__osoba__stanowisko.html#a161a70d3faff50c13d35616bdf233ce6", null ],
    [ "$_aliases", "classep___orzeczenie__sp__osoba__stanowisko.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_orzeczenie_sp", "classep___orzeczenie__sp__osoba__stanowisko.html#aa2e1ecb50e6fae26a854ac995f7226b8", null ],
    [ "$_orzeczenie_sp_osoba", "classep___orzeczenie__sp__osoba__stanowisko.html#aa30d4201fc3a8b5a7765a48d49d5fce3", null ],
    [ "$_orzeczenie_sp_stanowisko", "classep___orzeczenie__sp__osoba__stanowisko.html#a40db8434e34a6782c8dbb2e847a99d40", null ]
];