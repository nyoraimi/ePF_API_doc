var classep___api =
[
    [ "call", "classep___api.html#a2d4655622385b620a6f18270d0026fd8", null ],
    [ "$_version", "classep___api.html#a01caaf3772469caf98e39064bf5d7d8f", null ],
    [ "$server_address", "classep___api.html#affbb88357e7d111cab3d11d6623828b2", null ]
];