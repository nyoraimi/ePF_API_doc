var classep___s_n___jednostka =
[
    [ "__toString", "classep___s_n___jednostka.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___s_n___jednostka.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "orzeczenia_sn", "classep___s_n___jednostka.html#a1da449088f8d852fb2a7a425e8036b13", null ],
    [ "$_aliases", "classep___s_n___jednostka.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___s_n___jednostka.html#a4a4d54ae35428077a7c61ec8a5139af3", null ],
    [ "$_orzeczenia_sn", "classep___s_n___jednostka.html#a6f02468de85c0d4fa4f284d88f064662", null ]
];