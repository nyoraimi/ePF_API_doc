var classep___s_p___sad =
[
    [ "__toString", "classep___s_p___sad.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___s_p___sad.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "orzeczenia_sp", "classep___s_p___sad.html#a0253193f97ea82c02858e0b933a74880", null ],
    [ "$_aliases", "classep___s_p___sad.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___s_p___sad.html#a4a4d54ae35428077a7c61ec8a5139af3", null ],
    [ "$_orzeczenia_sp", "classep___s_p___sad.html#a460ae26a90178f807b8ccda9dcbc90a4", null ]
];