var classep___sejm___interpelacja =
[
    [ "__toString", "classep___sejm___interpelacja.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___sejm___interpelacja.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "poslowie", "classep___sejm___interpelacja.html#a0f86bc9d504d1c4a3a60c1585cb85f97", null ],
    [ "tablica", "classep___sejm___interpelacja.html#a562ec137b68d83aa36dd84a6f26c3394", null ],
    [ "$_aliases", "classep___sejm___interpelacja.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___sejm___interpelacja.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];