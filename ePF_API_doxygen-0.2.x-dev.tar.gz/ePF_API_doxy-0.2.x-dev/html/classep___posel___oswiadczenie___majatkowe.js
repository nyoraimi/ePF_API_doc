var classep___posel___oswiadczenie___majatkowe =
[
    [ "__toString", "classep___posel___oswiadczenie___majatkowe.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___posel___oswiadczenie___majatkowe.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "posel", "classep___posel___oswiadczenie___majatkowe.html#ad3b9fc55831f7bcabb4870306bc08f4b", null ],
    [ "set_ep_poslowie", "classep___posel___oswiadczenie___majatkowe.html#a6a354494d54778bcc9254b5826b5f28c", null ],
    [ "$_aliases", "classep___posel___oswiadczenie___majatkowe.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___posel___oswiadczenie___majatkowe.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];