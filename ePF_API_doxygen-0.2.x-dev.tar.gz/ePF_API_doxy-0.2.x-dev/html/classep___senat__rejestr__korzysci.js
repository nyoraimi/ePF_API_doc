var classep___senat__rejestr__korzysci =
[
    [ "__toString", "classep___senat__rejestr__korzysci.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___senat__rejestr__korzysci.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "senator", "classep___senat__rejestr__korzysci.html#af076312b536f7707cda87563bd9113d9", null ],
    [ "set_ep_senatorowie", "classep___senat__rejestr__korzysci.html#a92c4ef3c275a33bee3292b42c47233cd", null ],
    [ "$_aliases", "classep___senat__rejestr__korzysci.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___senat__rejestr__korzysci.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];