var files =
[
    [ "ep__Dataset.php", "ep_____dataset_8php.html", [
      [ "ep__Dataset", "classep_____dataset.html", "classep_____dataset" ]
    ] ],
    [ "ep__Object.php", "ep_____object_8php.html", [
      [ "ep__Object", "classep_____object.html", "classep_____object" ]
    ] ],
    [ "classes/ep_API.php", "classes_2ep___a_p_i_8php.html", "classes_2ep___a_p_i_8php" ],
    [ "ep_API.php", "ep___a_p_i_8php.html", "ep___a_p_i_8php" ],
    [ "ep_Autoloader.php", "ep___autoloader_8php.html", [
      [ "ep_Autoloader", "classep___autoloader.html", "classep___autoloader" ]
    ] ],
    [ "ep_BDL_Grupa.php", "ep___b_d_l___grupa_8php.html", [
      [ "ep_BDL_Grupa", "classep___b_d_l___grupa.html", "classep___b_d_l___grupa" ]
    ] ],
    [ "ep_BDL_Kategoria.php", "ep___b_d_l___kategoria_8php.html", [
      [ "ep_BDL_Kategoria", "classep___b_d_l___kategoria.html", "classep___b_d_l___kategoria" ]
    ] ],
    [ "ep_BDL_Podgrupa.php", "ep___b_d_l___podgrupa_8php.html", [
      [ "ep_BDL_Podgrupa", "classep___b_d_l___podgrupa.html", "classep___b_d_l___podgrupa" ]
    ] ],
    [ "ep_BDL_Wskaznik_Wariacja.php", "ep___b_d_l___wskaznik___wariacja_8php.html", [
      [ "ep_BDL_Wskaznik_Wariacja", "classep___b_d_l___wskaznik___wariacja.html", "classep___b_d_l___wskaznik___wariacja" ]
    ] ],
    [ "ep_Bip_Instytucja.php", "ep___bip___instytucja_8php.html", [
      [ "ep_Bip_Instytucja", "classep___bip___instytucja.html", "classep___bip___instytucja" ]
    ] ],
    [ "ep_Czlowiek.php", "ep___czlowiek_8php.html", [
      [ "ep_Czlowiek", "classep___czlowiek.html", "classep___czlowiek" ]
    ] ],
    [ "ep_Dataset.php", "ep___dataset_8php.html", [
      [ "ep_Dataset", "classep___dataset.html", "classep___dataset" ]
    ] ],
    [ "ep_Glosowanie_Sejmowe_Glos.php", "ep___glosowanie___sejmowe___glos_8php.html", [
      [ "ep_Glosowanie_Sejmowe_Glos", "classep___glosowanie___sejmowe___glos.html", "classep___glosowanie___sejmowe___glos" ]
    ] ],
    [ "ep_Gmina.php", "ep___gmina_8php.html", [
      [ "ep_Gmina", "classep___gmina.html", "classep___gmina" ]
    ] ],
    [ "ep_Instytucja.php", "ep___instytucja_8php.html", [
      [ "ep_Instytucja", "classep___instytucja.html", "classep___instytucja" ]
    ] ],
    [ "ep_ISAP_Plik.php", "ep___i_s_a_p___plik_8php.html", [
      [ "ep_ISAP_Plik", "classep___i_s_a_p___plik.html", "classep___i_s_a_p___plik" ]
    ] ],
    [ "ep_Kod_Pocztowy.php", "ep___kod___pocztowy_8php.html", [
      [ "ep_Kod_Pocztowy", "classep___kod___pocztowy.html", "classep___kod___pocztowy" ]
    ] ],
    [ "ep_KRS_Wpis.php", "ep___k_r_s___wpis_8php.html", [
      [ "ep_KRS_Wpis", "classep___k_r_s___wpis.html", "classep___k_r_s___wpis" ]
    ] ],
    [ "ep_Legislacja_Projekt.php", "ep___legislacja___projekt_8php.html", [
      [ "ep_Legislacja_Projekt", "classep___legislacja___projekt.html", "classep___legislacja___projekt" ]
    ] ],
    [ "ep_Legislacja_Projekt_Etap.php", "ep___legislacja___projekt___etap_8php.html", [
      [ "ep_Legislacja_Projekt_Etap", "classep___legislacja___projekt___etap.html", "classep___legislacja___projekt___etap" ]
    ] ],
    [ "ep_Legislacja_Projekt_Podpis.php", "ep___legislacja___projekt___podpis_8php.html", [
      [ "ep_Legislacja_Projekt_Podpis", "classep___legislacja___projekt___podpis.html", "classep___legislacja___projekt___podpis" ]
    ] ],
    [ "ep_Legislacja_Projekt_Status.php", "ep___legislacja___projekt___status_8php.html", [
      [ "ep_Legislacja_Projekt_Status", "classep___legislacja___projekt___status.html", "classep___legislacja___projekt___status" ]
    ] ],
    [ "ep_Miejscowosc.php", "ep___miejscowosc_8php.html", [
      [ "ep_Miejscowosc", "classep___miejscowosc.html", "classep___miejscowosc" ]
    ] ],
    [ "ep_NIK_Raport.php", "ep___n_i_k___raport_8php.html", [
      [ "ep_NIK_Raport", "classep___n_i_k___raport.html", "classep___n_i_k___raport" ]
    ] ],
    [ "ep_Object.php", "ep___object_8php.html", [
      [ "ep_Object", "classep___object.html", "classep___object" ]
    ] ],
    [ "ep_Orzeczenie_sp_osoba_stanowisko.php", "ep___orzeczenie__sp__osoba__stanowisko_8php.html", [
      [ "ep_Orzeczenie_sp_osoba_stanowisko", "classep___orzeczenie__sp__osoba__stanowisko.html", "classep___orzeczenie__sp__osoba__stanowisko" ]
    ] ],
    [ "ep_PNA.php", "ep___p_n_a_8php.html", [
      [ "ep_PNA", "classep___p_n_a.html", "classep___p_n_a" ]
    ] ],
    [ "ep_Posel.php", "ep___posel_8php.html", [
      [ "ep_Posel", "classep___posel.html", "classep___posel" ]
    ] ],
    [ "ep_Posel_Aktywnosc.php", "ep___posel___aktywnosc_8php.html", [
      [ "ep_Posel_Aktywnosc", "classep___posel___aktywnosc.html", "classep___posel___aktywnosc" ]
    ] ],
    [ "ep_Posel_Glos.php", "ep___posel___glos_8php.html", [
      [ "ep_Posel_Glos", "classep___posel___glos.html", "classep___posel___glos" ]
    ] ],
    [ "ep_Posel_Komisja_Stanowisko.php", "ep___posel___komisja___stanowisko_8php.html", [
      [ "ep_Posel_Komisja_Stanowisko", "classep___posel___komisja___stanowisko.html", "classep___posel___komisja___stanowisko" ]
    ] ],
    [ "ep_Posel_Oswiadczenie_Majatkowe.php", "ep___posel___oswiadczenie___majatkowe_8php.html", [
      [ "ep_Posel_Oswiadczenie_Majatkowe", "classep___posel___oswiadczenie___majatkowe.html", "classep___posel___oswiadczenie___majatkowe" ]
    ] ],
    [ "ep_Posel_Rejestr_Korzysci.php", "ep___posel___rejestr___korzysci_8php.html", [
      [ "ep_Posel_Rejestr_Korzysci", "classep___posel___rejestr___korzysci.html", "classep___posel___rejestr___korzysci" ]
    ] ],
    [ "ep_Posel_Wspolpracownik.php", "ep___posel___wspolpracownik_8php.html", [
      [ "ep_Posel_Wspolpracownik", "classep___posel___wspolpracownik.html", "classep___posel___wspolpracownik" ]
    ] ],
    [ "ep_Powiat.php", "ep___powiat_8php.html", [
      [ "ep_Powiat", "classep___powiat.html", "classep___powiat" ]
    ] ],
    [ "ep_Prawo.php", "ep___prawo_8php.html", [
      [ "ep_Prawo", "classep___prawo.html", "classep___prawo" ]
    ] ],
    [ "ep_Prawo_Typ.php", "ep___prawo___typ_8php.html", [
      [ "ep_Prawo_Typ", "classep___prawo___typ.html", "classep___prawo___typ" ]
    ] ],
    [ "ep_RCL_Dokument.php", "ep___r_c_l___dokument_8php.html", [
      [ "ep_RCL_Dokument", "classep___r_c_l___dokument.html", "classep___r_c_l___dokument" ]
    ] ],
    [ "ep_RCL_Projekt.php", "ep___r_c_l___projekt_8php.html", [
      [ "ep_RCL_Projekt", "classep___r_c_l___projekt.html", "classep___r_c_l___projekt" ]
    ] ],
    [ "ep_RCL_Projekt_Etap.php", "ep___r_c_l___projekt___etap_8php.html", [
      [ "ep_RCL_Projekt_Etap", "classep___r_c_l___projekt___etap.html", "classep___r_c_l___projekt___etap" ]
    ] ],
    [ "ep_RCL_Projekt_Status.php", "ep___r_c_l___projekt___status_8php.html", [
      [ "ep_RCL_Projekt_Status", "classep___r_c_l___projekt___status.html", "classep___r_c_l___projekt___status" ]
    ] ],
    [ "ep_SA_Orzeczenie.php", "ep___s_a___orzeczenie_8php.html", [
      [ "ep_SA_Orzeczenie", "classep___s_a___orzeczenie.html", "classep___s_a___orzeczenie" ]
    ] ],
    [ "ep_SA_Orzeczenie_Wynik.php", "ep___s_a___orzeczenie___wynik_8php.html", [
      [ "ep_SA_Orzeczenie_Wynik", "classep___s_a___orzeczenie___wynik.html", "classep___s_a___orzeczenie___wynik" ]
    ] ],
    [ "ep_SA_Sad.php", "ep___s_a___sad_8php.html", [
      [ "ep_SA_Sad", "classep___s_a___sad.html", "classep___s_a___sad" ]
    ] ],
    [ "ep_SA_Sedzia.php", "ep___s_a___sedzia_8php.html", [
      [ "ep_SA_Sedzia", "classep___s_a___sedzia.html", "classep___s_a___sedzia" ]
    ] ],
    [ "ep_SA_Skarzony_Organ.php", "ep___s_a___skarzony___organ_8php.html", [
      [ "ep_SA_Skarzony_Organ", "classep___s_a___skarzony___organ.html", "classep___s_a___skarzony___organ" ]
    ] ],
    [ "ep_Search.php", "ep___search_8php.html", [
      [ "ep_Search", "classep___search.html", "classep___search" ]
    ] ],
    [ "ep_Sejm_Dezyderat.php", "ep___sejm___dezyderat_8php.html", [
      [ "ep_Sejm_Dezyderat", "classep___sejm___dezyderat.html", "classep___sejm___dezyderat" ]
    ] ],
    [ "ep_Sejm_Druk.php", "ep___sejm___druk_8php.html", [
      [ "ep_Sejm_Druk", "classep___sejm___druk.html", "classep___sejm___druk" ]
    ] ],
    [ "ep_Sejm_Druk_Typ.php", "ep___sejm___druk___typ_8php.html", [
      [ "ep_Sejm_Druk_Typ", "classep___sejm___druk___typ.html", "classep___sejm___druk___typ" ]
    ] ],
    [ "ep_Sejm_Dzien.php", "ep___sejm___dzien_8php.html", [
      [ "ep_Sejm_Dzien", "classep___sejm___dzien.html", "classep___sejm___dzien" ]
    ] ],
    [ "ep_Sejm_Glosowanie.php", "ep___sejm___glosowanie_8php.html", [
      [ "ep_Sejm_Glosowanie", "classep___sejm___glosowanie.html", "classep___sejm___glosowanie" ]
    ] ],
    [ "ep_Sejm_Glosowanie_Glos.php", "ep___sejm___glosowanie___glos_8php.html", [
      [ "ep_Sejm_Glosowanie_Glos", "classep___sejm___glosowanie___glos.html", "classep___sejm___glosowanie___glos" ]
    ] ],
    [ "ep_Sejm_Glosowanie_Typ.php", "ep___sejm___glosowanie___typ_8php.html", [
      [ "ep_Sejm_Glosowanie_Typ", "classep___sejm___glosowanie___typ.html", "classep___sejm___glosowanie___typ" ]
    ] ],
    [ "ep_Sejm_Interpelacja.php", "ep___sejm___interpelacja_8php.html", [
      [ "ep_Sejm_Interpelacja", "classep___sejm___interpelacja.html", "classep___sejm___interpelacja" ]
    ] ],
    [ "ep_Sejm_Interpelacja_Pismo.php", "ep___sejm___interpelacja___pismo_8php.html", [
      [ "ep_Sejm_Interpelacja_Pismo", "classep___sejm___interpelacja___pismo.html", "classep___sejm___interpelacja___pismo" ]
    ] ],
    [ "ep_Sejm_Klub.php", "ep___sejm___klub_8php.html", [
      [ "ep_Sejm_Klub", "classep___sejm___klub.html", "classep___sejm___klub" ]
    ] ],
    [ "ep_Sejm_Komisja.php", "ep___sejm___komisja_8php.html", [
      [ "ep_Sejm_Komisja", "classep___sejm___komisja.html", "classep___sejm___komisja" ]
    ] ],
    [ "ep_Sejm_Komunikat.php", "ep___sejm___komunikat_8php.html", [
      [ "ep_Sejm_Komunikat", "classep___sejm___komunikat.html", "classep___sejm___komunikat" ]
    ] ],
    [ "ep_Sejm_Okreg_Wyborczy.php", "ep___sejm___okreg___wyborczy_8php.html", [
      [ "ep_Sejm_Okreg_Wyborczy", "classep___sejm___okreg___wyborczy.html", "classep___sejm___okreg___wyborczy" ]
    ] ],
    [ "ep_Sejm_Posiedzenie.php", "ep___sejm___posiedzenie_8php.html", [
      [ "ep_Sejm_Posiedzenie", "classep___sejm___posiedzenie.html", "classep___sejm___posiedzenie" ]
    ] ],
    [ "ep_Sejm_Posiedzenie_Debata.php", "ep___sejm___posiedzenie___debata_8php.html", [
      [ "ep_Sejm_Posiedzenie_Debata", "classep___sejm___posiedzenie___debata.html", "classep___sejm___posiedzenie___debata" ]
    ] ],
    [ "ep_Sejm_Posiedzenie_Punkt.php", "ep___sejm___posiedzenie___punkt_8php.html", [
      [ "ep_Sejm_Posiedzenie_Punkt", "classep___sejm___posiedzenie___punkt.html", "classep___sejm___posiedzenie___punkt" ]
    ] ],
    [ "ep_Sejm_Pytanie_Biezace.php", "ep___sejm___pytanie___biezace_8php.html", [
      [ "ep_Sejm_Pytanie_Biezace", "classep___sejm___pytanie___biezace.html", "classep___sejm___pytanie___biezace" ]
    ] ],
    [ "ep_Sejm_Sprawozdanie.php", "ep___sejm___sprawozdanie_8php.html", [
      [ "ep_Sejm_Sprawozdanie", "classep___sejm___sprawozdanie.html", "classep___sejm___sprawozdanie" ]
    ] ],
    [ "ep_Sejm_Wniesiony_Projekt.php", "ep___sejm___wniesiony___projekt_8php.html", [
      [ "ep_Sejm_Wniesiony_Projekt", "classep___sejm___wniesiony___projekt.html", "classep___sejm___wniesiony___projekt" ]
    ] ],
    [ "ep_Sejm_Wystapienie.php", "ep___sejm___wystapienie_8php.html", [
      [ "ep_Sejm_Wystapienie", "classep___sejm___wystapienie.html", "classep___sejm___wystapienie" ]
    ] ],
    [ "ep_Senat_Druk.php", "ep___senat___druk_8php.html", [
      [ "ep_Senat_Druk", "classep___senat___druk.html", "classep___senat___druk" ]
    ] ],
    [ "ep_Senat_komisja.php", "ep___senat__komisja_8php.html", [
      [ "ep_Senat_komisja", "classep___senat__komisja.html", "classep___senat__komisja" ]
    ] ],
    [ "ep_Senat_Oswiadczenie_Majatkowe.php", "ep___senat___oswiadczenie___majatkowe_8php.html", [
      [ "ep_Senat_Oswiadczenie_Majatkowe", "classep___senat___oswiadczenie___majatkowe.html", "classep___senat___oswiadczenie___majatkowe" ]
    ] ],
    [ "ep_Senat_rejestr_korzysci.php", "ep___senat__rejestr__korzysci_8php.html", [
      [ "ep_Senat_rejestr_korzysci", "classep___senat__rejestr__korzysci.html", "classep___senat__rejestr__korzysci" ]
    ] ],
    [ "ep_Senat_senator_komisja.php", "ep___senat__senator__komisja_8php.html", [
      [ "ep_Senat_senator_komisja", "classep___senat__senator__komisja.html", "classep___senat__senator__komisja" ]
    ] ],
    [ "ep_Senat_senator_zespol_parlamentarny.php", "ep___senat__senator__zespol__parlamentarny_8php.html", [
      [ "ep_Senat_senator_zespol_parlamentarny", "classep___senat__senator__zespol__parlamentarny.html", "classep___senat__senator__zespol__parlamentarny" ]
    ] ],
    [ "ep_Senat_senator_zespol_senacki.php", "ep___senat__senator__zespol__senacki_8php.html", [
      [ "ep_Senat_senator_zespol_senacki", "classep___senat__senator__zespol__senacki.html", "classep___senat__senator__zespol__senacki" ]
    ] ],
    [ "ep_Senat_Wystapienie.php", "ep___senat___wystapienie_8php.html", [
      [ "ep_Senat_Wystapienie", "classep___senat___wystapienie.html", "classep___senat___wystapienie" ]
    ] ],
    [ "ep_Senat_Zespol.php", "ep___senat___zespol_8php.html", [
      [ "ep_Senat_Zespol", "classep___senat___zespol.html", "classep___senat___zespol" ]
    ] ],
    [ "ep_Senat_zespol_parlamentarny.php", "ep___senat__zespol__parlamentarny_8php.html", [
      [ "ep_Senat_zespol_parlamentarny", "classep___senat__zespol__parlamentarny.html", "classep___senat__zespol__parlamentarny" ]
    ] ],
    [ "ep_Senator.php", "ep___senator_8php.html", [
      [ "ep_Senator", "classep___senator.html", "classep___senator" ]
    ] ],
    [ "ep_SN_Izba.php", "ep___s_n___izba_8php.html", [
      [ "ep_SN_Izba", "classep___s_n___izba.html", "classep___s_n___izba" ]
    ] ],
    [ "ep_SN_Jednostka.php", "ep___s_n___jednostka_8php.html", [
      [ "ep_SN_Jednostka", "classep___s_n___jednostka.html", "classep___s_n___jednostka" ]
    ] ],
    [ "ep_SN_Orzeczenie.php", "ep___s_n___orzeczenie_8php.html", [
      [ "ep_SN_Orzeczenie", "classep___s_n___orzeczenie.html", "classep___s_n___orzeczenie" ]
    ] ],
    [ "ep_SN_Orzeczenie_Autor.php", "ep___s_n___orzeczenie___autor_8php.html", [
      [ "ep_SN_Orzeczenie_Autor", "classep___s_n___orzeczenie___autor.html", "classep___s_n___orzeczenie___autor" ]
    ] ],
    [ "ep_SN_Orzeczenie_Forma.php", "ep___s_n___orzeczenie___forma_8php.html", [
      [ "ep_SN_Orzeczenie_Forma", "classep___s_n___orzeczenie___forma.html", "classep___s_n___orzeczenie___forma" ]
    ] ],
    [ "ep_SN_Orzeczenie_Izba.php", "ep___s_n___orzeczenie___izba_8php.html", [
      [ "ep_SN_Orzeczenie_Izba", "classep___s_n___orzeczenie___izba.html", "classep___s_n___orzeczenie___izba" ]
    ] ],
    [ "ep_SN_Orzeczenie_Sedzia.php", "ep___s_n___orzeczenie___sedzia_8php.html", [
      [ "ep_SN_Orzeczenie_Sedzia", "classep___s_n___orzeczenie___sedzia.html", "classep___s_n___orzeczenie___sedzia" ]
    ] ],
    [ "ep_SN_Osoba.php", "ep___s_n___osoba_8php.html", [
      [ "ep_SN_Osoba", "classep___s_n___osoba.html", "classep___s_n___osoba" ]
    ] ],
    [ "ep_SN_Sklad.php", "ep___s_n___sklad_8php.html", [
      [ "ep_SN_Sklad", "classep___s_n___sklad.html", "classep___s_n___sklad" ]
    ] ],
    [ "ep_SN_Wspolsprawozdawca.php", "ep___s_n___wspolsprawozdawca_8php.html", [
      [ "ep_SN_Wspolsprawozdawca", "classep___s_n___wspolsprawozdawca.html", "classep___s_n___wspolsprawozdawca" ]
    ] ],
    [ "ep_SP_Haslo.php", "ep___s_p___haslo_8php.html", [
      [ "ep_SP_Haslo", "classep___s_p___haslo.html", "classep___s_p___haslo" ]
    ] ],
    [ "ep_SP_Haslo_Tematyczne.php", "ep___s_p___haslo___tematyczne_8php.html", [
      [ "ep_SP_Haslo_Tematyczne", "classep___s_p___haslo___tematyczne.html", "classep___s_p___haslo___tematyczne" ]
    ] ],
    [ "ep_SP_Orzeczenie.php", "ep___s_p___orzeczenie_8php.html", [
      [ "ep_SP_Orzeczenie", "classep___s_p___orzeczenie.html", "classep___s_p___orzeczenie" ]
    ] ],
    [ "ep_SP_Orzeczenie_Czesc.php", "ep___s_p___orzeczenie___czesc_8php.html", [
      [ "ep_SP_Orzeczenie_Czesc", "classep___s_p___orzeczenie___czesc.html", "classep___s_p___orzeczenie___czesc" ]
    ] ],
    [ "ep_SP_Orzeczenie_Przepis.php", "ep___s_p___orzeczenie___przepis_8php.html", [
      [ "ep_SP_Orzeczenie_Przepis", "classep___s_p___orzeczenie___przepis.html", "classep___s_p___orzeczenie___przepis" ]
    ] ],
    [ "ep_SP_Osoba.php", "ep___s_p___osoba_8php.html", [
      [ "ep_SP_Osoba", "classep___s_p___osoba.html", "classep___s_p___osoba" ]
    ] ],
    [ "ep_SP_Sad.php", "ep___s_p___sad_8php.html", [
      [ "ep_SP_Sad", "classep___s_p___sad.html", "classep___s_p___sad" ]
    ] ],
    [ "ep_SP_Stanowisko.php", "ep___s_p___stanowisko_8php.html", [
      [ "ep_SP_Stanowisko", "classep___s_p___stanowisko.html", "classep___s_p___stanowisko" ]
    ] ],
    [ "ep_SP_Teza.php", "ep___s_p___teza_8php.html", [
      [ "ep_SP_Teza", "classep___s_p___teza.html", "classep___s_p___teza" ]
    ] ],
    [ "ep_Stanowisko.php", "ep___stanowisko_8php.html", [
      [ "ep_Stanowisko", "classep___stanowisko.html", "classep___stanowisko" ]
    ] ],
    [ "ep_Twitt.php", "ep___twitt_8php.html", [
      [ "ep_Twitt", "classep___twitt.html", "classep___twitt" ]
    ] ],
    [ "ep_Twitt_Tag.php", "ep___twitt___tag_8php.html", [
      [ "ep_Twitt_Tag", "classep___twitt___tag.html", "classep___twitt___tag" ]
    ] ],
    [ "ep_Ustawa.php", "ep___ustawa_8php.html", [
      [ "ep_Ustawa", "classep___ustawa.html", "classep___ustawa" ]
    ] ],
    [ "ep_Wojewodztwo.php", "ep___wojewodztwo_8php.html", [
      [ "ep_Wojewodztwo", "classep___wojewodztwo.html", "classep___wojewodztwo" ]
    ] ],
    [ "sp_Orzeczenie_SN_Sprawozdawca.php", "sp___orzeczenie___s_n___sprawozdawca_8php.html", [
      [ "sp_Orzeczenie_SN_Sprawozdawca", "classsp___orzeczenie___s_n___sprawozdawca.html", "classsp___orzeczenie___s_n___sprawozdawca" ]
    ] ]
];