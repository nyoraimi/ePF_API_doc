var classep___senat___oswiadczenie___majatkowe =
[
    [ "__toString", "classep___senat___oswiadczenie___majatkowe.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___senat___oswiadczenie___majatkowe.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "senator", "classep___senat___oswiadczenie___majatkowe.html#af076312b536f7707cda87563bd9113d9", null ],
    [ "set_ep_senatorowie", "classep___senat___oswiadczenie___majatkowe.html#a92c4ef3c275a33bee3292b42c47233cd", null ],
    [ "$_aliases", "classep___senat___oswiadczenie___majatkowe.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];