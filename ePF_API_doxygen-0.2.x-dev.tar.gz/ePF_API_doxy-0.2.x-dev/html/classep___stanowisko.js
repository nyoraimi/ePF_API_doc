var classep___stanowisko =
[
    [ "__toString", "classep___stanowisko.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___stanowisko.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "$_aliases", "classep___stanowisko.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___stanowisko.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];