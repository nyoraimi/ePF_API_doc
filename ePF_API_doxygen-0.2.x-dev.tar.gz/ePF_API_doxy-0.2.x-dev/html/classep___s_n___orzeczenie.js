var classep___s_n___orzeczenie =
[
    [ "__toString", "classep___s_n___orzeczenie.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "autorzy", "classep___s_n___orzeczenie.html#ac66efa4209f50d765772be02a881381e", null ],
    [ "forma", "classep___s_n___orzeczenie.html#a608fa64fd97142801ced83ea87121df2", null ],
    [ "getDataStruct", "classep___s_n___orzeczenie.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "izby_orzeczenia", "classep___s_n___orzeczenie.html#a5f63a0d971299ec2faf962f75055dd16", null ],
    [ "jednostka", "classep___s_n___orzeczenie.html#a9770abfccd8d758bc47ff823619f4322", null ],
    [ "sedziowie", "classep___s_n___orzeczenie.html#a8a15d60da65e02bae2cbdbf37b916e9f", null ],
    [ "sklad", "classep___s_n___orzeczenie.html#a6b9228e10a1bc1f8a597116e902d231d", null ],
    [ "sprawozdawcy", "classep___s_n___orzeczenie.html#a76d3ecd15358754b888e8224f0bb525d", null ],
    [ "wspolsprawozdawcy", "classep___s_n___orzeczenie.html#a6c6f87dc07e219e95c13638d943a60eb", null ],
    [ "$_aliases", "classep___s_n___orzeczenie.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_autorzy", "classep___s_n___orzeczenie.html#a979f172256d5c0c7e9a858abeddcfc18", null ],
    [ "$_field_init_lookup", "classep___s_n___orzeczenie.html#a4a4d54ae35428077a7c61ec8a5139af3", null ],
    [ "$_forma", "classep___s_n___orzeczenie.html#a95b4aef311558b8233d9934bd08406ec", null ],
    [ "$_izby_orzeczenia", "classep___s_n___orzeczenie.html#a32e61795984a518ce9fe14cbd1a68306", null ],
    [ "$_jednostka", "classep___s_n___orzeczenie.html#ad1b42e8f431ce2f82d2ccf9395587947", null ],
    [ "$_sedziowie", "classep___s_n___orzeczenie.html#a9515f25f368eef1b6825d9568f40c4bc", null ],
    [ "$_sklad", "classep___s_n___orzeczenie.html#aeeba512286131af36395e8e6bddafbac", null ],
    [ "$_sprawozdawcy", "classep___s_n___orzeczenie.html#a714759738f329fda5eebaffc97a6be38", null ],
    [ "$_wspolsprawozdawcy", "classep___s_n___orzeczenie.html#ad912d3fe15f8233d48bc2a574708cfc2", null ]
];