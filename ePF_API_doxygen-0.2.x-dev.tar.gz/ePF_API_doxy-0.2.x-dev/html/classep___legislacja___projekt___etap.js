var classep___legislacja___projekt___etap =
[
    [ "__toString", "classep___legislacja___projekt___etap.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___legislacja___projekt___etap.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "parse_data", "classep___legislacja___projekt___etap.html#ac313783ab7146c71e639bf7ddf54b0db", null ],
    [ "$_aliases", "classep___legislacja___projekt___etap.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];