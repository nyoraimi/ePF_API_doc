var classep___senat__senator__zespol__parlamentarny =
[
    [ "__toString", "classep___senat__senator__zespol__parlamentarny.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "get_stanowisko", "classep___senat__senator__zespol__parlamentarny.html#a24e5fcbf4661581e53314bf23f908b7a", null ],
    [ "getDataStruct", "classep___senat__senator__zespol__parlamentarny.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "senator", "classep___senat__senator__zespol__parlamentarny.html#af076312b536f7707cda87563bd9113d9", null ],
    [ "zespol_parlamentarny", "classep___senat__senator__zespol__parlamentarny.html#ab35c0c9aed2d5fc6af85be9289f9f2a1", null ],
    [ "$_aliases", "classep___senat__senator__zespol__parlamentarny.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];