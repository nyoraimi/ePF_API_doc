var classep___p_n_a =
[
    [ "getDataStruct", "classep___p_n_a.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "gmina", "classep___p_n_a.html#ae13445f31d6a2e43182ca0e2ce2f821d", null ],
    [ "powiat", "classep___p_n_a.html#afeb09b2f0c7a3cd1d9bfe029ffdd57ea", null ],
    [ "wojewodztwo", "classep___p_n_a.html#a2c735142a4af50d47b17d8103a9ab9ab", null ],
    [ "$_aliases", "classep___p_n_a.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_gmina", "classep___p_n_a.html#ab0313b743bc1be610472dfee711e929a", null ],
    [ "$_powiat", "classep___p_n_a.html#a928275f8378baade592a64f89da229ef", null ],
    [ "$_wojewodztwo", "classep___p_n_a.html#a2a0a830e555a9e31b5118be82dbc33c7", null ]
];