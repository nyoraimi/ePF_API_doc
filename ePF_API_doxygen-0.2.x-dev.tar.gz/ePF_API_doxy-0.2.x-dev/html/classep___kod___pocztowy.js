var classep___kod___pocztowy =
[
    [ "getDataStruct", "classep___kod___pocztowy.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "gminy", "classep___kod___pocztowy.html#a885f04b428d85dab7d92552ae9dba979", null ],
    [ "wojewodztwo", "classep___kod___pocztowy.html#a2c735142a4af50d47b17d8103a9ab9ab", null ],
    [ "$_aliases", "classep___kod___pocztowy.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___kod___pocztowy.html#a4a4d54ae35428077a7c61ec8a5139af3", null ],
    [ "$_wojewodztwo", "classep___kod___pocztowy.html#a2a0a830e555a9e31b5118be82dbc33c7", null ]
];