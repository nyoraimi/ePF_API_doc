var classep___sejm___glosowanie =
[
    [ "__toString", "classep___sejm___glosowanie.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "debata", "classep___sejm___glosowanie.html#a7fe12606c5b0d87a6f1d26d2470a10c2", null ],
    [ "dzien", "classep___sejm___glosowanie.html#a211a968a9f3aa1e4a58516f8c344ec00", null ],
    [ "getDataStruct", "classep___sejm___glosowanie.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "glosy", "classep___sejm___glosowanie.html#aab9cc82c80e91ad71187a3c4a9999561", null ],
    [ "kluby", "classep___sejm___glosowanie.html#aa8056e435aeb70114dcd8800fd64a142", null ],
    [ "posiedzenie", "classep___sejm___glosowanie.html#abfdc29f0533665ad6c77341c5fa3f7c7", null ],
    [ "wystapienie", "classep___sejm___glosowanie.html#aa051a476b68537f178e14ee797250288", null ],
    [ "$_aliases", "classep___sejm___glosowanie.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___sejm___glosowanie.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];