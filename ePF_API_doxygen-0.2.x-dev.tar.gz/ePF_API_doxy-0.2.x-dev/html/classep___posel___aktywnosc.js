var classep___posel___aktywnosc =
[
    [ "__toString", "classep___posel___aktywnosc.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___posel___aktywnosc.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "$_aliases", "classep___posel___aktywnosc.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];