var classep___s_n___osoba =
[
    [ "__toString", "classep___s_n___osoba.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___s_n___osoba.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "orzeczenia_sn_autorzy", "classep___s_n___osoba.html#ad1853509afa0c61a80737e642e6ac4b3", null ],
    [ "orzeczenia_sn_sedziowie", "classep___s_n___osoba.html#a27c2edb4c314d7f1b6e15e46fd4f29f3", null ],
    [ "orzeczenia_sn_sprawozdawcy", "classep___s_n___osoba.html#af7d6fce395a80d9a1fce72e15a178bc2", null ],
    [ "orzeczenia_sn_wspolsprawozdawcy", "classep___s_n___osoba.html#a9fbf7de2cd78bb13631c5b55dd7c9d96", null ],
    [ "$_aliases", "classep___s_n___osoba.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___s_n___osoba.html#a4a4d54ae35428077a7c61ec8a5139af3", null ],
    [ "$_orzeczenia_sn_autorzy", "classep___s_n___osoba.html#a1631803c32c7cbe2dfd7642d66fdffeb", null ],
    [ "$_orzeczenia_sn_sedziowie", "classep___s_n___osoba.html#a87a2b9afde5e31d31c0d136ea7de8c94", null ],
    [ "$_orzeczenia_sn_sprawozdawcy", "classep___s_n___osoba.html#aa9207c65eeb1a9686772f302fcaa2f3a", null ],
    [ "$_orzeczenia_sn_wspolsprawozdawcy", "classep___s_n___osoba.html#a1b717768eb8101ecc84cb85e8109ba25", null ]
];