var classep___senat__senator__komisja =
[
    [ "__toString", "classep___senat__senator__komisja.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "get_stanowisko", "classep___senat__senator__komisja.html#a24e5fcbf4661581e53314bf23f908b7a", null ],
    [ "getDataStruct", "classep___senat__senator__komisja.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "komisja", "classep___senat__senator__komisja.html#a1d71a6ebf9406f2a818e18f4df5a5728", null ],
    [ "senator", "classep___senat__senator__komisja.html#af076312b536f7707cda87563bd9113d9", null ],
    [ "$_aliases", "classep___senat__senator__komisja.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];