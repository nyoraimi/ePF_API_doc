var classep___s_n___izba =
[
    [ "__toString", "classep___s_n___izba.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___s_n___izba.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "orzeczenia", "classep___s_n___izba.html#afafcff5d2bf7a4b4dd56b1a0a7c6a275", null ],
    [ "$_aliases", "classep___s_n___izba.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___s_n___izba.html#a4a4d54ae35428077a7c61ec8a5139af3", null ],
    [ "$_orzeczenia", "classep___s_n___izba.html#aa013b5921d7a844cc79c7e3a5ffbd03a", null ]
];