var classep___s_p___orzeczenie =
[
    [ "__toString", "classep___s_p___orzeczenie.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "bloki", "classep___s_p___orzeczenie.html#ac6344ab36289e3d6b79a0fdae42d2146", null ],
    [ "getDataStruct", "classep___s_p___orzeczenie.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "hasla", "classep___s_p___orzeczenie.html#a5aa6a641a9d13bc9350ba92b07680244", null ],
    [ "osoby_stanowiska", "classep___s_p___orzeczenie.html#aeed2d21ed1c7ed38d96e4ff27dead9cd", null ],
    [ "przepisy", "classep___s_p___orzeczenie.html#a5a7fd63e53799ac8f60829be1adc37e1", null ],
    [ "sad_sp", "classep___s_p___orzeczenie.html#a938cd0e29c0e27685e0402857cf681e7", null ],
    [ "$_aliases", "classep___s_p___orzeczenie.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_bloki", "classep___s_p___orzeczenie.html#aee90f3b27d0ab721378343d2bd0d71ba", null ],
    [ "$_hasla", "classep___s_p___orzeczenie.html#a7b7a4173e85d440890bd5305cfd10667", null ],
    [ "$_osoby_stanowiska", "classep___s_p___orzeczenie.html#a652b265eb5a0c97e3cbad17334ceffe8", null ],
    [ "$_przepisy", "classep___s_p___orzeczenie.html#a070b291e5f4d9685f5e035cfe91aaa7e", null ],
    [ "$_sad_sp", "classep___s_p___orzeczenie.html#a811580445f6e2ef962379396050552c6", null ]
];