var classep___sejm___dzien =
[
    [ "__construct", "classep___sejm___dzien.html#a8c384d5e0f13f64cbf8c51096faa7738", null ],
    [ "__toString", "classep___sejm___dzien.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "debaty", "classep___sejm___dzien.html#a61f284b69abf1b9994fb0531fd5072ec", null ],
    [ "getDataStruct", "classep___sejm___dzien.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "posiedzenie", "classep___sejm___dzien.html#abfdc29f0533665ad6c77341c5fa3f7c7", null ],
    [ "set_ep_sejm_posiedzenia", "classep___sejm___dzien.html#a1ebe2368dbaefa70f34cea7885c4cbdd", null ],
    [ "$_aliases", "classep___sejm___dzien.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];