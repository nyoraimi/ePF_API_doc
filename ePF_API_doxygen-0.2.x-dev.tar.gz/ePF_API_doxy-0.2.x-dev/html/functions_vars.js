var functions_vars =
[
    [ "$", "functions_vars.html", null ],
    [ "t", "functions_vars_0x74.html", null ]
];