var classep___powiat =
[
    [ "__toString", "classep___powiat.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___powiat.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "obszar", "classep___powiat.html#aa05db5ea090acb5d431aff0bbb8b97a6", null ],
    [ "set_ep_wojewodztwo", "classep___powiat.html#ada1a8341471222061c3c8ae5bae028f3", null ],
    [ "wojewodztwo", "classep___powiat.html#a2c735142a4af50d47b17d8103a9ab9ab", null ],
    [ "$_aliases", "classep___powiat.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___powiat.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];