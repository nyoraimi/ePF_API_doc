var classep___posel___komisja___stanowisko =
[
    [ "__toString", "classep___posel___komisja___stanowisko.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___posel___komisja___stanowisko.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "komisja", "classep___posel___komisja___stanowisko.html#a1d71a6ebf9406f2a818e18f4df5a5728", null ],
    [ "posel", "classep___posel___komisja___stanowisko.html#ad3b9fc55831f7bcabb4870306bc08f4b", null ],
    [ "set_ep_poslowie", "classep___posel___komisja___stanowisko.html#a6a354494d54778bcc9254b5826b5f28c", null ],
    [ "set_ep_sejm_komisje", "classep___posel___komisja___stanowisko.html#a1a21d8ba0207f2d4a8c26575c8b30970", null ],
    [ "$_aliases", "classep___posel___komisja___stanowisko.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];