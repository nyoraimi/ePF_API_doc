var classep___sejm___glosowanie___glos =
[
    [ "__toString", "classep___sejm___glosowanie___glos.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___sejm___glosowanie___glos.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "$_aliases", "classep___sejm___glosowanie___glos.html#ab4e31d75f0bc5d512456911e5d01366b", null ]
];