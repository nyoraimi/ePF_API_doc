var classep___prawo =
[
    [ "__toString", "classep___prawo.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "getDataStruct", "classep___prawo.html#a79dabf680e30ee6e62508a8df24ed243", null ],
    [ "getDescription", "classep___prawo.html#a2e7bb35c71bf1824456ceb944cb7a845", null ],
    [ "$_aliases", "classep___prawo.html#ab4e31d75f0bc5d512456911e5d01366b", null ],
    [ "$_field_init_lookup", "classep___prawo.html#a4a4d54ae35428077a7c61ec8a5139af3", null ]
];